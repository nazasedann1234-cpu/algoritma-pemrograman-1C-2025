harga_sewa_motor_matic = 50.000.00
harga_sewa_motor_trail = 100.000.00
harga_sewa_motor_sport = 75.000.00
diskon = 10%

if sewa > 3 hari= :
    print(f"asuransi Rp. 15.000.00")
elif harga_sewa_motor_matic > 3  :
    print("harga_sewa * total")
elif harga_sewa_motor_trail > 3  :
    print("harga_sewa * total")
elif harga_sewa_motor_sport > 3   :
    print("harga_sewa * total")
elif diskon 10% total > Rp. 150.000.00 :
    print("total > Rp. 150.000.00")

    while is.alpha("AconkGG")
        print("diskon 5%")
        continue






  
 